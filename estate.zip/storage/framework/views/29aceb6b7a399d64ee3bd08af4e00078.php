<?php echo $__env->make('admin_dash.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_dash.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_dash.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container-xl">
        <h1 class="app-page-title">Edit wallet</h1>

        <?php echo $__env->make('admin_dash.components.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row p-4 g-4 mb-4">
            <div class="app-card col-12 col-lg-23">
                <div class="app-card-header p-3">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-auto">
                            <h4 class="app-card-title">Wallet Details</h4>
                        </div>
                    </div>
                </div>

                <div class="auth-form-container app-card-body p-3 p-lg-4 text-left">
                    <?php if(Session::has('message')): ?>
                    <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('error')): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
                    <?php endif; ?>

                    <form class="auth-form resetpass-form" action="/admins/deposit/add" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="email mb-3">
                            <p>Coin</p>
                            <input id="reg-email" name="coin" type="text" class="form-control login-email" placeholder="The Desired Coin" required="required">
                        </div>
                        <!--//form-group-->
                        <div class="email mb-3">
                            <p>Wallet Address</p>
                            <input id="reg-email" name="wallet" type="text" placeholder="The Accurate Wallet Address" class="form-control login-email" required="required">
                        </div>
                        <!--//form-group-->
                        <div class="text-center">
                            <button type="submit" class="btn app-btn-primary btn-block theme-btn mx-auto">Add method</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin_dash.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_dash.components.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\empire_estate\estate\resources\views/admin_dash/add_deposit_method.blade.php ENDPATH**/ ?>