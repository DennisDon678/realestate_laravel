<?php echo $__env->make('admin_dash.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_dash.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_dash.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container-xl">
        <h1 class="app-page-title">Withdrawal Info</h1>

        <?php echo $__env->make('admin_dash.components.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row p-4 g-4 mb-4">
            <div class="app-card col-12 col-lg-6">
                <div class="app-card-header p-3">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-auto">
                            <h4 class="app-card-title">Withdrawal Details</h4>
                        </div>
                    </div>
                </div>

                <div class="auth-form-container app-card-body p-3 p-lg-4 text-left">
                    <?php if(Session::has('message')): ?>
                    <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>

                    <?php if(Session::has('error')): ?>
                    <p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
                    <?php endif; ?>

                    <form class="auth-form resetpass-form" action="/dashboard/deposit" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="usd" value="<?php echo e($_GET['amount']); ?>">
                        <div class="email mb-3">
                            <p>Amount</p>
                            <input id="reg-email" name="amount" type="text" class="form-control login-email" value='<?php echo e($deposit['amount']); ?> <?php echo e($deposit['coin']); ?>' required="required" readonly>
                        </div>
                        <!--//form-group-->
                        <div class="email mb-3">
                            <p>Prefered coin</p>
                            <input id="reg-email" name="coin" type="email" class="form-control login-email" value='<?php echo e($deposit['coin']); ?>' required="required" readonly>
                        </div>
                        <!--//form-group-->

                        <div class="email mb-3">
                            <p>Wallet address</p>
                            <input id="reg-email" name="wallet" type="email" class="form-control login-email" value='<?php echo e($deposit['address']); ?>' required="required" readonly>
                        </div>
                        <!--//form-group-->
                        <div class="email mb-3">
                            <p>Screenshot</p>
                            <input id="reg-email" name="image" type="file" class="form-control " value='<?php echo e($deposit['address']); ?>' required="required">
                        </div>
                        <!--//form-group-->
                        <div class="text-center">
                            <button type="submit" class="btn app-btn-primary btn-block theme-btn mx-auto">Deposit</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="app-card app-card-stats-table h-100 shadow-sm">
                    <div class="app-card-header p-3">
                        <div class="row justify-content-between align-items-center">
                            <div class="col-auto">
                                <h4 class="app-card-title">History</h4>
                            </div>
                        </div>
                        <!--//row-->
                    </div>
                    <!--//app-card-header-->
                    <div class="app-card-body p-3 p-lg-4">
                        <div class="table-responsive">
                            <table class="table table-borderless mb-0">
                                <thead>
                                    <tr>
                                        <th class="meta">ID</th>
                                        <th class="meta stat-cell">Amount</th>
                                        <th class="meta stat-cell">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($historys) > 0): ?>
                                    <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <tr>
                                        <td><a href="#"><?php echo e($history->transaction_id); ?></a></td>
                                        <td class="stat-cell">$<?php echo e($history->usd_amount); ?></td>
                                        <td class="stat-cell"><?php echo e($history->status); ?></td>
                                    </tr>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan='5'>
                                            <p class='text-center text-danger'>No Deposit has been made!</p>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!--//table-responsive-->
                    </div>
                    <!--//app-card-body-->
                </div>
                <!--//app-card-->
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin_dash.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin_dash.components.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\empire_estate\estate\resources\views/admin_dash/deposit.blade.php ENDPATH**/ ?>