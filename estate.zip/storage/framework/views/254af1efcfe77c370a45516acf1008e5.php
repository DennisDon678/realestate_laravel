<?php echo $__env->make('user_dash.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user_dash.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user_dash.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container-xl">
        <h1 class="app-page-title">Select plan</h1>

        <?php echo $__env->make('user_dash.components.finance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row g-1">
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 wow p-2 fadeInUp app-card" data-wow-delay="0.1s">
                <div class="property-item rounded overflow-hidden">
                    <div class="position-relative overflow-hidden">
                        <a href=""><img class="img-fluid" src="<?php echo e(asset('img/property-'.$plan->id.'.jpg')); ?>" alt=""></a>
                        <?php if($plan->id == 1): ?>
                            <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">Simple Budget</div>
                        <?php elseif($plan->id == 2): ?>
                            <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3"><span class="nav-icon" style='padding:2px; color:orange;'><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-fire" viewBox="0 0 16 16">
                                        <path d="M8 16c3.314 0 6-2 6-5.5 0-1.5-.5-4-2.5-6 .25 1.5-1.25 2-1.25 2C11 4 9 .5 6 0c.357 2 .5 4-2 6-1.25 1-2 2.729-2 4.5C2 14 4.686 16 8 16Zm0-1c-1.657 0-3-1-3-2.75 0-.75.25-2 1.25-3C6.125 10 7 10.5 7 10.5c-.375-1.25.5-3.25 2-3.5-.179 1-.25 2 1 3 .625.5 1 1.364 1 2.25C11 14 9.657 15 8 15Z" />
                                    </svg></span>Popular</div>
                        <?php elseif($plan->id == 3): ?>
                            <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">VIP Offers</div>
                        <?php endif; ?>
                    
                    </div>
                    <div class="p-4 pb-0">
                        <a class="d-block h5 mb-2" href="">Details:</a>
                        <p><strong><?php echo e($plan->plan_name); ?></strong></p>
                        <p>Duration: <?php echo e($plan->duration); ?> Months</p>
                        <p>Rate: 
                        <?php if($plan->id == 1): ?>
                            10 - 12 percent
                        <?php elseif($plan->id == 2): ?>
                            30 percent
                        <?php elseif($plan->id == 3): ?>
                            45 percent
                        <?php endif; ?>
                        </p>

                        <p>Min-amount:
                            <?php if($plan->id == 1): ?>
                            1000 USD
                            <?php elseif($plan->id == 2): ?>
                            30,000 USD
                            <?php elseif($plan->id == 3): ?>
                            100,000 USD
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="p-4 pb-0">
                        <a class="d-block text-white btn btn-primary mb-2" href="/dashboard/invest/<?php echo e($plan->id); ?>">Select</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--//col-->
        </div>

    </div>
</div>
<?php echo $__env->make('user_dash.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user_dash.components.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\empire_estate\estate\resources\views/user_dash/invest_type.blade.php ENDPATH**/ ?>