 <footer class="app-footer">
     <div class="container text-center py-3">
        
         <small class="copyright">&copy; Terms applied</small>

     </div>
 </footer>
 <!--//app-footer-->