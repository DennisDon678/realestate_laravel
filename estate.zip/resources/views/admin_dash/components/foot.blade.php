
    </div>
<!-- Javascript -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="{{asset('admin/assets/plugins/popper.min.js')}}"></script>
<script src="{{asset('admin/assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>

<!-- Charts JS -->
<script src="{{asset('admin/assets/plugins/chart.js/chart.min.js')}}"></script>
<script src="{{asset('admin/assets/js/index-charts.js')}}"></script>

<!-- Page Specific JS -->
<script src="{{asset('admin/assets/js/app.js')}}"></script>

<noscript>
    <input type="submit" value="Submit form!" />
</noscript>

</body>
</html>
