@include('user_dash.components.head')
@include('user_dash.components.nav')
@include('user_dash.components.sidebar')

@include('user_dash.components.overview')

@include('user_dash.components.footer')
@include('user_dash.components.foot')